#!/bin/bash

/usr/local/bin/gnsync --path "/var/cloudbackups/workdir/evernote" --download-only --all