#!/bin/bash

/usr/bin/github-backup "$GITHUB_USER" "/var/cloudbackups/workdir/github/"