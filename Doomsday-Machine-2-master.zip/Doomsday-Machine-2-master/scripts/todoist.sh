#!/bin/bash

/usr/bin/todoist-backup --config /etc/cloudbackup/todoist.json