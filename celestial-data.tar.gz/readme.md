# Celestial map with D3.js

### Usage


```js
  example code
```


Supported projections: equirectangular, hammer, ..  
most of these need the extension [d3.geo.projections](https://github.com/d3/d3-geo-projection/)  

### Files

__GeoJSON data files__

* `stars.6.json` Stars down to 6th magnitude \[1\]
* `stars.7.json` Stars down to 7th magnitude \[1\]
  
* `dsos.6.json` Deep space objects down to 6th magnitude \[2\]
* `dsos.7.json` Deep space objects down to 7th magnitude \[2\]
* `dsos.bright.json` Some of the brightest showpiece DSOs of my own choosing
  
* `constellations.json` Constellation data  \[3\]
* `constellations.bounds.json` Constellation boundaries \[4\]
* `constellations.lines.json` Constellation lines \[3\]
  
* `mw.json` Milky way outlines in 5 brightness steps \[5\]



### Sources

\[1\] XHIP: An Extended Hipparcos Compilation; Anderson E., Francis C. (2012) [VizieR catalogue V/137D](http://cdsarc.u-strasbg.fr/viz-bin/Cat?V/137D)  
\[2\] [Saguaro Astronomy Club Database version 8.1](http://www.saguaroastro.org/content/downloads.htm)  
\[3\] [IAU Constellation page](http://www.iau.org/public/themes/constellations/), name positions and some line modifications by me  
\[4\] Catalogue of Constellation Boundary Data; Davenhall A.C., Leggett S.K. (1989) [VizieR catalogue VI/49/](http://vizier.cfa.harvard.edu/viz-bin/Cat?VI/49)  
\[5\] [Milky Way Outline Catalog](http://www.skymap.com/milkyway_cat.htm), Jose R. Vieira  

all data converted to GeoJSON at J2000 epoch 
