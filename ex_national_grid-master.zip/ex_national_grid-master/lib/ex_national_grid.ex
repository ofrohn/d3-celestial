defmodule ExNationalGrid do
  def hello, do: :world
end
