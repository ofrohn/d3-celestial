defmodule ExNationalGridTest do
  use ExUnit.Case
  doctest ExNationalGrid

  test "greets the world" do
    assert ExNationalGrid.hello() == :world
  end
end
